package utils;

public class ArrayUtils {
    /** Prints each integer and its position.
     * @param nums the array to display
     */
    public static void displayArray(int[] nums) {
        for (int i = 0; i < nums.length; i++) {
            System.out.println("Position " + i + ": " + nums[i]);
        }
    }

    /** Prints each String and its position.
     * @param text the array to display
     */
    public static void displayArray(String[] text) {
        for (int i = 0; i < text.length; i++) {
            System.out.println("Position " + i + ": " + text[i]);
        }
    }

    /** Calculates the average of an integer array.
     * @param nums the numbers to average
     * @return the average, or 0.0 if the array is empty
     */
    public static double calcAverage(int[] nums) {
        if (nums.length == 0) return 0.0;
        int total = 0;
        for (int num : nums) total += num;
        return (double) total / nums.length;
    }

    /** Finds the largest integer.
     * @param nums the numbers to check
     * @return the largest number, or 0 if the array is empty
     */
    public static int findMax(int[] nums) {
        if (nums.length == 0) return 0;
        int max = nums[0];
        for (int num : nums) if (num > max) max = num;
        return max;
    }

    /** Finds the String that comes last alphabetically, ignoring case.
     * @param text the Strings to check
     * @return the last String alphabetically, or null if empty
     */
    public static String findMax(String[] text) {
        if (text.length == 0) return null;
        String max = text[0];
        for (String word : text)
            if (word.compareToIgnoreCase(max) > 0) max = word;
        return max;
    }

    /** Finds the smallest integer.
     * @param nums the numbers to check
     * @return the smallest number, or 0 if the array is empty
     */
    public static int findMin(int[] nums) {
        if (nums.length == 0) return 0;
        int min = nums[0];
        for (int num : nums) if (num < min) min = num;
        return min;
    }

    /** Finds the String that comes first alphabetically, ignoring case.
     * @param text the Strings to check
     * @return the first String alphabetically, or null if empty
     */
    public static String findMin(String[] text) {
        if (text.length == 0) return null;
        String min = text[0];
        for (String word : text)
            if (word.compareToIgnoreCase(min) < 0) min = word;
        return min;
    }

    /** Counts how often a value appears.
     * @param nums the array to search
     * @param value the value to count
     * @return the number of occurrences
     */
    public static int count(int[] nums, int value) {
        int total = 0;
        for (int num : nums) if (num == value) total++;
        return total;
    }

    /** Finds the most frequent value; ties return the first tied value encountered.
     * @param nums the array to check
     * @return the most frequent value, or 0 for an empty array
     */
    public static int getMostFrequent(int[] nums) {
        if (nums.length == 0) return 0;
        int mostFrequent = nums[0];
        int highestCount = count(nums, nums[0]);
        for (int num : nums) {
            int frequency = count(nums, num);
            if (frequency > highestCount) {
                highestCount = frequency;
                mostFrequent = num;
            }
        }
        return mostFrequent;
    }

    /** Counts values greater than a supplied value.
     * @param nums the array to check
     * @param value the comparison value
     * @return the number of values greater than value
     */
    public static int countGreater(int[] nums, int value) {
        int total = 0;
        for (int num : nums) if (num > value) total++;
        return total;
    }

    /** Counts values greater than the array average.
     * @param nums the array to check
     * @return the number of values above the average
     */
    public static int countGreaterThanAverage(int[] nums) {
        if (nums.length == 0) return 0;
        double average = calcAverage(nums);
        int total = 0;
        for (int num : nums) if (num > average) total++;
        return total;
    }

    /** Creates an integer array with ten extra slots.
     * @param nums the original array
     * @return the larger array containing the original values
     */
    public static int[] grow(int[] nums) {
        int[] result = new int[nums.length + 10];
        for (int i = 0; i < nums.length; i++) result[i] = nums[i];
        return result;
    }

    /** Copies a String array to a requested size.
     * @param text the original array
     * @param newSize the required size
     * @return the new array containing as many original values as fit
     */
    public static String[] resize(String[] text, int newSize) {
        if (newSize < 0) throw new IllegalArgumentException("Size cannot be negative.");
        String[] result = new String[newSize];
        int limit = Math.min(text.length, newSize);
        for (int i = 0; i < limit; i++) result[i] = text[i];
        return result;
    }

    /** Removes duplicates from an unsorted array using array growth.
     * @param nums the input array
     * @return distinct values in first-appearance order
     */
    public static int[] deduplicate(int[] nums) {
        int[] result = new int[0];
        for (int value : nums) {
            boolean found = false;
            for (int kept : result) {
                if (kept == value) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                int[] larger = new int[result.length + 1];
                for (int i = 0; i < result.length; i++) larger[i] = result[i];
                larger[larger.length - 1] = value;
                result = larger;
            }
        }
        return result;
    }

    /** Removes duplicate grades using -1 as a temporary blank marker.
     * @param grades grades from 0 to 100
     * @return the grades without duplicates in first-appearance order
     */
    public static int[] filterDuplicates(int[] grades) {
        int[] work = new int[grades.length];
        for (int i = 0; i < grades.length; i++) work[i] = grades[i];

        for (int i = 0; i < work.length; i++) {
            if (work[i] == -1) continue;
            for (int j = i + 1; j < work.length; j++)
                if (work[j] == work[i]) work[j] = -1;
        }

        int count = 0;
        for (int value : work) if (value != -1) count++;
        int[] result = new int[count];
        int next = 0;
        for (int value : work) if (value != -1) result[next++] = value;
        return result;
    }

    /** Removes adjacent duplicates from an ascending sorted array.
     * @param nums the array sorted in ascending order
     * @return the correctly sized array with duplicates removed
     */
    public static int[] sortedDeduplicate(int[] nums) {
        if (nums.length == 0) return new int[0];
        int size = 1;
        for (int i = 1; i < nums.length; i++)
            if (nums[i] != nums[i - 1]) size++;
        int[] result = new int[size];
        result[0] = nums[0];
        int next = 1;
        for (int i = 1; i < nums.length; i++)
            if (nums[i] != nums[i - 1]) result[next++] = nums[i];
        return result;
    }

    /** Merges two integer arrays, preserving their input order.
     * @param nums1 the first array
     * @param nums2 the second array
     * @return the merged array
     */
    public static int[] merge(int[] nums1, int[] nums2) {
        int[] result = new int[nums1.length + nums2.length];
        for (int i = 0; i < nums1.length; i++) result[i] = nums1[i];
        for (int i = 0; i < nums2.length; i++) result[nums1.length + i] = nums2[i];
        return result;
    }

    /** Merges two ascending integer arrays into ascending order.
     * @param nums1 the first sorted array
     * @param nums2 the second sorted array
     * @return the merged sorted array
     */
    public static int[] orderedMerge(int[] nums1, int[] nums2) {
        int[] result = new int[nums1.length + nums2.length];
        int i = 0, j = 0, k = 0;
        while (i < nums1.length && j < nums2.length) {
            if (nums1[i] <= nums2[j]) result[k++] = nums1[i++];
            else result[k++] = nums2[j++];
        }
        while (i < nums1.length) result[k++] = nums1[i++];
        while (j < nums2.length) result[k++] = nums2[j++];
        return result;
    }

    /** Merges two alphabetically sorted String arrays, ignoring case.
     * @param text1 the first sorted array
     * @param text2 the second sorted array
     * @return the merged sorted array
     */
    public static String[] orderedMerge(String[] text1, String[] text2) {
        String[] result = new String[text1.length + text2.length];
        int i = 0, j = 0, k = 0;
        while (i < text1.length && j < text2.length) {
            if (text1[i].compareToIgnoreCase(text2[j]) <= 0) result[k++] = text1[i++];
            else result[k++] = text2[j++];
        }
        while (i < text1.length) result[k++] = text1[i++];
        while (j < text2.length) result[k++] = text2[j++];
        return result;
    }

    /** Places values greater than pivot first, followed by values at or below it.
     * @param nums the values to partition
     * @param pivot the dividing value
     * @return the partitioned array, not a fully sorted array
     */
    public static int[] partition(int[] nums, int pivot) {
        int[] lowerOrEqual = new int[nums.length];
        int[] greater = new int[nums.length];
        int lowCount = 0, highCount = 0;
        for (int value : nums) {
            if (value <= pivot) lowerOrEqual[lowCount++] = value;
            else greater[highCount++] = value;
        }
        int[] lowUsed = new int[lowCount];
        int[] highUsed = new int[highCount];
        for (int i = 0; i < lowCount; i++) lowUsed[i] = lowerOrEqual[i];
        for (int i = 0; i < highCount; i++) highUsed[i] = greater[i];
        return merge(highUsed, lowUsed);
    }

    /** Partitions Strings around a pivot using case-insensitive comparison.
     * @param text the Strings to partition
     * @param pivot the String pivot
     * @return values greater than pivot followed by values at or below it
     */
    public static String[] partition(String[] text, String pivot) {
        String[] lowerOrEqual = new String[text.length];
        String[] greater = new String[text.length];
        int lowCount = 0, highCount = 0;
        for (String value : text) {
            if (value.compareToIgnoreCase(pivot) <= 0) lowerOrEqual[lowCount++] = value;
            else greater[highCount++] = value;
        }
        String[] result = new String[text.length];
        int next = 0;
        for (int i = 0; i < highCount; i++) result[next++] = greater[i];
        for (int i = 0; i < lowCount; i++) result[next++] = lowerOrEqual[i];
        return result;
    }
}
