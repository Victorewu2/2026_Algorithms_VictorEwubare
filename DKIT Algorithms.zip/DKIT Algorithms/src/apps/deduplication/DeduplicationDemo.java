package apps.deduplication;

import utils.ArrayUtils;
import java.util.Arrays;
import java.util.Scanner;

public class DeduplicationDemo {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("How many grades will you enter? ");
        int size = readInt(input);
        while (size < 0) {
            System.out.print("Enter zero or more: ");
            size = readInt(input);
        }

        int[] grades = new int[size];
        for (int i = 0; i < grades.length; i++) {
            System.out.print("Enter grade " + (i + 1) + " (0-100): ");
            grades[i] = readInt(input);
            while (grades[i] < 0 || grades[i] > 100) {
                System.out.print("Enter a grade from 0 to 100: ");
                grades[i] = readInt(input);
            }
        }

        int[] growth = ArrayUtils.deduplicate(grades);
        int[] blank = ArrayUtils.filterDuplicates(grades);
        int[] sorted = Arrays.copyOf(grades, grades.length);
        Arrays.sort(sorted);
        int[] sortedUnique = ArrayUtils.sortedDeduplicate(sorted);

        System.out.println("Original: " + Arrays.toString(grades));
        System.out.println("Array growth: " + Arrays.toString(growth));
        System.out.println("Blank deletion: " + Arrays.toString(blank));
        System.out.println("Sorted input: " + Arrays.toString(sorted));
        System.out.println("Sorted deduplication: " + Arrays.toString(sortedUnique));
        System.out.println("Duplicates removed: " + (grades.length - growth.length));

        System.out.println("Repeated values: " + Arrays.toString(ArrayUtils.deduplicate(new int[]{4, 4, 7, 7, 2})));
        System.out.println("No duplicates: " + Arrays.toString(ArrayUtils.deduplicate(new int[]{1, 2, 3})));
        System.out.println("Single value: " + Arrays.toString(ArrayUtils.deduplicate(new int[]{9})));
        System.out.println("Empty array: " + Arrays.toString(ArrayUtils.deduplicate(new int[]{})));
    }

    private static int readInt(Scanner input) {
        while (!input.hasNextInt()) {
            System.out.print("Enter a whole number: ");
            input.next();
        }
        return input.nextInt();
    }
}
