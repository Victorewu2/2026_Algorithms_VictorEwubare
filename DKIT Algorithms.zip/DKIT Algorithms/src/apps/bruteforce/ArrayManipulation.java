package apps.bruteforce;

import utils.ArrayUtils;
import java.util.Scanner;

public class ArrayManipulation {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] grades = new int[10];

        for (int i = 0; i < grades.length; i++) {
            System.out.print("Enter grade " + (i + 1) + ": ");
            while (!input.hasNextInt()) {
                System.out.print("Enter a whole number: ");
                input.next();
            }
            grades[i] = input.nextInt();
        }

        System.out.println("\nGrades:");
        ArrayUtils.displayArray(grades);
        System.out.println("Average: " + ArrayUtils.calcAverage(grades));
        System.out.println("Highest grade: " + ArrayUtils.findMax(grades));
        System.out.println("Lowest grade: " + ArrayUtils.findMin(grades));
        System.out.println("Number of grades equal to 70: " + ArrayUtils.count(grades, 70));
        System.out.println("Most frequent grade: " + ArrayUtils.getMostFrequent(grades));
        System.out.println("Grades above average: " + ArrayUtils.countGreaterThanAverage(grades));

        input.nextLine();
        System.out.print("\nWould you like to enter 10 words? (yes/no): ");
        if (input.nextLine().equalsIgnoreCase("yes")) {
            String[] words = new String[10];
            for (int i = 0; i < words.length; i++) {
                System.out.print("Enter word " + (i + 1) + ": ");
                words[i] = input.nextLine();
            }
            ArrayUtils.displayArray(words);
            System.out.println("Last alphabetically: " + ArrayUtils.findMax(words));
            System.out.println("First alphabetically: " + ArrayUtils.findMin(words));
        }
    }
}
