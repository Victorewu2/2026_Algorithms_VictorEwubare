package apps.resizing;

import utils.ArrayUtils;
import java.util.Scanner;

public class ArrayResizing {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Initial number of integer slots: ");
        int size = readInt(input);
        while (size < 0) {
            System.out.print("Enter zero or more: ");
            size = readInt(input);
        }

        int[] numbers = new int[size];
        int used = 0;
        while (true) {
            while (used < numbers.length) {
                System.out.print("Enter integer for position " + used + ": ");
                numbers[used++] = readInt(input);
            }
            System.out.print("Array is full. Add more numbers? (yes/no): ");
            if (!input.next().equalsIgnoreCase("yes")) break;
            numbers = ArrayUtils.grow(numbers);
        }

        int[] entered = new int[used];
        for (int i = 0; i < used; i++) entered[i] = numbers[i];
        System.out.println("Numbers entered:");
        ArrayUtils.displayArray(entered);

        input.nextLine();
        String[] words = new String[2];
        int wordCount = 0;
        while (true) {
            System.out.print("Do you want to enter a word? (yes/no): ");
            if (!input.nextLine().equalsIgnoreCase("yes")) break;
            if (wordCount == words.length) words = ArrayUtils.resize(words, words.length + 2);
            System.out.print("Enter word: ");
            words[wordCount++] = input.nextLine();
        }

        String[] allWords = ArrayUtils.resize(words, wordCount);
        System.out.println("Words entered:");
        ArrayUtils.displayArray(allWords);
        System.out.print("How many words do you want to keep? ");
        int keep = readInt(input);
        while (keep < 0 || keep > allWords.length) {
            System.out.print("Enter a number from 0 to " + allWords.length + ": ");
            keep = readInt(input);
        }
        ArrayUtils.displayArray(ArrayUtils.resize(allWords, keep));
    }

    private static int readInt(Scanner input) {
        while (!input.hasNextInt()) {
            System.out.print("Enter a whole number: ");
            input.next();
        }
        return input.nextInt();
    }
}
