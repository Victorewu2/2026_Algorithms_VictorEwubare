package apps.mergingpartitioning;

import utils.ArrayUtils;
import java.util.Arrays;
import java.util.Scanner;

public class NumberMerging {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] first = readFive(input, "first");
        int[] second = readFive(input, "second");

        System.out.println("Merged in input order:");
        ArrayUtils.displayArray(ArrayUtils.merge(first, second));

        Arrays.sort(first);
        Arrays.sort(second);
        System.out.println("First sorted array: " + Arrays.toString(first));
        System.out.println("Second sorted array: " + Arrays.toString(second));
        System.out.println("Merged in ascending order:");
        ArrayUtils.displayArray(ArrayUtils.orderedMerge(first, second));
    }

    private static int[] readFive(Scanner input, String label) {
        int[] values = new int[5];
        for (int i = 0; i < values.length; i++) {
            System.out.print("Enter " + label + " number " + (i + 1) + ": ");
            while (!input.hasNextInt()) {
                System.out.print("Enter a whole number: ");
                input.next();
            }
            values[i] = input.nextInt();
        }
        return values;
    }
}
