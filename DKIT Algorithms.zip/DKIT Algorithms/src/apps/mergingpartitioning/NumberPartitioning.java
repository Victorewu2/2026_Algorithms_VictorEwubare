package apps.mergingpartitioning;

import utils.ArrayUtils;
import java.util.Scanner;

public class NumberPartitioning {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] grades = new int[10];
        for (int i = 0; i < grades.length; i++) {
            System.out.print("Enter grade " + (i + 1) + ": ");
            while (!input.hasNextInt()) {
                System.out.print("Enter a whole number: ");
                input.next();
            }
            grades[i] = input.nextInt();
        }

        int pivot = 40;
        int[] result = ArrayUtils.partition(grades, pivot);
        System.out.println("Partitioned grades:");
        ArrayUtils.displayArray(result);
        System.out.println("Grades greater than 40: " + ArrayUtils.countGreater(grades, pivot));
    }
}
