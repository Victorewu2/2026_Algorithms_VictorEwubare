package apps.mergingpartitioning;

import utils.ArrayUtils;
import java.util.Scanner;

public class StringPartitioning {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] names = new String[10];
        for (int i = 0; i < names.length; i++) {
            System.out.print("Enter name " + (i + 1) + ": ");
            names[i] = input.nextLine();
        }
        System.out.print("Enter pivot name: ");
        String pivot = input.nextLine();

        System.out.println("Partitioned names:");
        ArrayUtils.displayArray(ArrayUtils.partition(names, pivot));
    }
}
