package apps.mergingpartitioning;

import utils.ArrayUtils;
import java.util.Arrays;
import java.util.Scanner;

public class StringMerging {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] first = readFive(input, "first");
        String[] second = readFive(input, "second");

        Arrays.sort(first, String.CASE_INSENSITIVE_ORDER);
        Arrays.sort(second, String.CASE_INSENSITIVE_ORDER);
        System.out.println("First array: " + Arrays.toString(first));
        System.out.println("Second array: " + Arrays.toString(second));
        System.out.println("Merged alphabetically:");
        ArrayUtils.displayArray(ArrayUtils.orderedMerge(first, second));
    }

    private static String[] readFive(Scanner input, String label) {
        String[] words = new String[5];
        for (int i = 0; i < words.length; i++) {
            System.out.print("Enter " + label + " word " + (i + 1) + ": ");
            words[i] = input.nextLine();
        }
        return words;
    }
}
